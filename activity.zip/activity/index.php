<?php 
include"includes/config.php";
if(isset($_POST['addTask'])){
	$title=$_POST['taskTitle'];
	$details=$_POST['taskDetails'];
	$sql=mysql_query("INSERT INTO task(taskTitle,taskDetails) VALUES('$title','$details')");
	if($sql)
		echo "<script language= 'JavaScript'>alert('Task Added.');</script>";
	else
		echo "<script language= 'JavaScript'>alert('Failed. Try again later.');</script>";
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
  		<meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Soding</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="css/mainActivity.css">
	</head>
	<body>
		<div class="container container-custom">
			<div class="row">
			  	<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-6-custom"><div class="createTask"><p><button type="button" class="btn btn-link btn-link-custom btn-lg" data-toggle="modal" data-target="#createTask"><span class='glyphicon glyphicon-plus-sign'></span><br>Create Task</button></p></div></div>
			  	<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-6-custom"><div class="listTask"><a href="listTask.php"><p><span class='glyphicon glyphicon-list'></span><br>List Task</p></a></div></div>
			</div>
			<div class="row">
			  	<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-6-custom"><div class="editTask"><p><span class='glyphicon glyphicon-edit'></span><br>Edit</p></div></div>
			  	<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 col-6-custom"><div class="deteleTask"><p><span class='glyphicon glyphicon-remove'></span><br>Delete</p></div></div>
			</div>
		</div>

		<div class="modal fade" id="createTask" role="dialog">
		    <div class="modal-dialog">
		    
		      <!-- Modal content-->
		      	<form class="form-horizontal" method="POST" action="">
			      	<div class="modal-content">
			       		<div class="modal-header">
			         		<button type="button" class="close" data-dismiss="modal">&times;</button>
			          		<h4 class="modal-title">Create Task</h4>
			        	</div>
			        	<div class="modal-body">
			          	    <div class="form-group">
					      		<label class="control-label col-sm-2" for="taskTitle">Title:</label>
					      		<div class="col-sm-10">
					        		<input type="text" class="form-control" id="taskTitle" placeholder="Enter Title" name="taskTitle" required="required">
					      		</div>
					    	</div>
					    	<div class="form-group">
					      		<label class="control-label col-sm-2" for="taskDetails">Details:</label>
					      		<div class="col-sm-10">          
					       			<textarea class="form-control" rows="5" id="taskDetails" name="taskDetails" placeholder="Task Description or details" required></textarea>
					      		</div>
					    	</div>
					    	
					 
			        	</div>
			        	<div class="modal-footer">
			          		<div class="form-group">        
					      		<div class="col-sm-offset-2 col-sm-10">
					        		<input type="submit" name="addTask" class="btn btn-default" value="Add Task">
					      		</div>
					    	</div>
			       		</div>
		    		</form>
		      	</div>
		      
		    </div>
		</div>
	</body>
</html>